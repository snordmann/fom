window.cmp_config_data_cs="CO-QrJJO-QrJJAfaUBDEBECgAAAAAAAAAAigFtQAQFtAW1ABAW0AgCgAgCEBgAQFtBIAIAhAoAEBbQaACAIQOABAW0IgAgCEEgAQFtDoAIAhB4AEBbRCACAIQiABAW0SgAgCEJgAQFtFIAIAhCoAEBbQ";
window.cmp_config_data={"cookiefree":0,"savepref":0,"lvt":-1,"bnc":0,"bnc2":0,"bncd":0,"iabid":31,"host":"consentmanager.mgr.consensu.org","host2":"www.consentmanager.net","cdn":"cdn.consentmanager.mgr.consensu.org","logo":"https:\/\/cdn.consentmanager.mgr.consensu.org\/delivery\/cmplogo.svg","logow":"16","logoh":"16","cmpname":"consentmanager.net","intID":11684,"uid":3039,"iuid":"","tcfversion":2,"setuniqueid":0,"consentscope":2,"cookiescope":0,"scopeid":0,"boolNoCMPLogo":"0","disablevendorswopurpose":0,"turnoffvendorswopurpose":1,"turnonvendorswopurpose":1,"disablevendorswopurposeall":0,"turnoffvendorswopurposeall":0,"turnonvendorswopurposeone":0,"hidevendortoggles":0,"hidevendors":0,"askagain":1602662473000,"regulation":1,"strSetFixedLanguage":"DE","defaultlang":"EN","boolCustomPurposeDefault":"0","boolCustomVendorsDefault":"0","enableRecallBtn":"3","ccpaRecallBtn":"0","rowRecallBtn":"0","oob":"0","welcomeprps":2,"welcomeprpsccpa":"0","islspa":0,"ccpavm":0,"boolGroupChoices":1,"intVersion":"42","intDesignVersion":"8","verifyage":"0","simplecookie":"1","recallIcon":"\/delivery\/cmplogo.svg","menu_vendors":1,"menu_privacy":1,"togglesinmenu":0,"custheadlineontop":0,"boolShowAllPurposeBtnTop":"1","boolShowAllPurposeBtnBottom":"0","boolShowAllVendorsBtnTop":"1","boolShowAllVendorsBtnBottom":"0","cookielist":"1","intAskAgainForNewVendorsDays":"365","intAskAgainDaysForRejectedUsers":"365","intAskAgainDaysForAcceptedUsers":"365","strLogoUrl":"\/\/consentmanager.mgr.consensu.org\/delivery\/img\/logo1590487178x6785.gif","strLogoClick":0,"tac":{"XX":"https:\/\/nwzonline.de\/agb"},"imp":{"XX":"https:\/\/www.nwzonline.de\/impressum"},"policytype":0,"strPolicyURL":"https:\/\/www.nwzmedien.de\/datenschutz\/nwzonline","strPolicyURLlang":"","ccpadnslogic":0,"ccpadns":"https:\/\/...","design_intID":1,"design_intPosition":"3","design_boolGrayOutWebsite":"1","design_intGrayOutClickBehavior":"0","design_intCloseClickBehavior":"1","design_toggle":13,"design_toggletxt":1,"design_listicon":0,"design_intScrollBehavior":"0","design_intScrollDepth":"100","design_intNavigateBehavior":"0","design_boolShowCountdown":"0","design_intCountdownTime":"45","design_intCountdownBehavior":"0","design_btns":3,"design_custombtns":0,"tcfcompliant":1,"strCustomCSS":"","strWebsite":"NWZonline","verGVLv1":215,"verGVLv2":68,"pubcc":"EU","compresscookie":0,"customLang":[],"vendors":[],"cvc":"___s23_s1592_s37_s1475_s1442_c977_U___","purposes":[{"id":"6","wsid":"11684","n":"Notwendig","t":"2","cp":",,","up":",,"},{"id":"1","wsid":"11684","v":"2"},{"id":"2","wsid":"11684","v":"2"},{"id":"3","wsid":"11684","v":"2"},{"id":"4","wsid":"11684","v":"2"},{"id":"7","wsid":"11684","v":"2"},{"id":"8","wsid":"11684","v":"2"},{"id":"9","wsid":"11684","v":"2"},{"id":"10","wsid":"11684","v":"2"},{"id":"1","wsid":"11684","v":"3"},{"id":"2","wsid":"11684","v":"3"}],"stacks":[{"id":"22","wsid":"11684","st":"2","p":"8,10"},{"id":"39","wsid":"11684","st":"2","p":"2,3,4,7,9,10"}],"cpc":"___6___","ccc":"","usps":"","fbid":"s7"};
if(!("cmp_scripts" in window)){window.cmp_scripts = [];}
if(!("cmp_scripturls" in window)){window.cmp_scripturls = [];}
if(!("cmp_proto" in window)){window.cmp_proto = "https:";}
 function cmp_loadCS()
 {
  var l=0;
  var k=[];
  for(var i=0;i<window.cmp_scripts.length;i++){if(window.cmp_scripts[i].substr(0,1)!="#"){l++; k.push(window.cmp_scripturls[i]);}}
  var lx = false;
  if("cmpmngr" in window)
  {
   if(l>0)
   {
    if(!("cmp_timer" in window)){window.cmp_timer = new Date();}
    var now = new Date();
    if((now.getTime() - window.cmp_timer.getTime()) > 3000)
    {
     //load scripts again
     for(var kx=0; kx<k.length; kx++)
     {
      cmp_append_script2(k[kx],"");
     }
    }
    if((now.getTime() - window.cmp_timer.getTime()) > 8000)
    {lx = true;}
   }
   else{lx=true;}
  }
  if(lx){window.cmpmngr.loadSettings(window.cmp_config_data_cs,{},window.cmp_config_data);}
  else{window.setTimeout("cmp_loadCS()",30);}
 };function cmp_append_script(s,r){window.cmp_scripts.push(r);window.cmp_scripturls.push(s);cmp_append_script2(s,r);}function cmp_append_script2(s,r){var o=document.createElement("script");o.async=true;o.type="text/javascript";o.setAttribute("data-cmp-ab","1");o.src=s;if(document.body){document.body.appendChild(o);}else if(document.currentScript){document.currentScript.parentElement.appendChild(o);}else{var s = document.getElementsByTagName("script");s = s[s.length - 1];s.parentElement.appendChild(o);}}cmp_append_script(window.cmp_proto+"//cdn.consentmanager.mgr.consensu.org/delivery/customcss/7102_11684_1.v8.js","css");cmp_append_script(window.cmp_proto+"//cdn.consentmanager.mgr.consensu.org/delivery/customvendors/11684_1.js","vendors");cmp_append_script(window.cmp_proto+"//cdn.consentmanager.mgr.consensu.org/delivery/customtexts/7102_3039.js","texts"); cmp_loadCS();