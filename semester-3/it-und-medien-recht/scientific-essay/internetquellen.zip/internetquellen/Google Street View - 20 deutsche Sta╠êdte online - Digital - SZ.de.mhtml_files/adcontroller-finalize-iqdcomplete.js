var IQDComplete = {
  init: function() {
    return true
  },
}

if (typeof AdController !== 'undefined') {
  AdController.finalize()
}
