// Setting iframe height
$('.myIframe').css('height', $(window).height()+'px');
